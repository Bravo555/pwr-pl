package app.map;

public class MapException extends Exception {
    public MapException(String message) {
        super(message);
    }
}
